package com.familyguard.ui

class LoginActivity {
}
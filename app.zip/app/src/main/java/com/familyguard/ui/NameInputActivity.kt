package com.familyguard.ui

class NameInputActivity {
}